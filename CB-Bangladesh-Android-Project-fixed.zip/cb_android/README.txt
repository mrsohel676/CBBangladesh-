CB Bangladesh Android Project

This project is an Android WebView wrapper for the CB Bangladesh web application.

Fixed in this version:
- Corrected Android back-button handling so WebView history works.
- Added WebView cleanup on activity destroy.
- Added Gradle wrapper configuration for Gradle 8.10.2.
- Kept INTERNET permission and HTTPS-only network policy.

Build:
1. Open this folder in Android Studio.
2. Let Android Studio sync/download the required Gradle and Android SDK components.
3. Build > Build APK(s).

Important:
The app currently loads the configured HTTPS web URL. The web application itself must be online and accessible for the app to display its content.
